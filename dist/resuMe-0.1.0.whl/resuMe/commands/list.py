import click

from resuMe.utils import list


@click.command()
def cli():
    """Lists all generated website locations"""
    list()
    